# Handoff: CA-3 project report (Computer Vision for Robotics)

## What it is
A LaTeX report on the CV Autonomous Navigation project: a ROS 2 / Gazebo / Nav2 robot with YOLOv8 perception, LiDAR-camera fusion, time-to-collision (TTC) safety, a SQLite topological memory, and semantic sign navigation. It is built on the professor's template (Symbiosis Institute of Technology, Department of Robotics and Automation). Guide: Dr. Sameer Sayyad. Team: Zubin Patnaik, Utkarsh Singh, Shubham Desai, Soham Darade. `main.pdf` is the current 53-page build.

## Structure
Folder layout:
- `main.tex` (template; do not change its core), `references.bib` (14 references, all checked against search results)
- `Front_Pages/title_page.tex`
- `Chapters/Ch_1 ... Ch_6` (one file per chapter)
- `Annexures/Design_Data.tex` (Annexure I and II), `Appendix/Appendix_A.tex` (placeholder for the similarity reports)
- `Figures/` (all images), `Misc/` (logo)

Chapters:
1. **Introduction**: background, motivation, recent trends (cited), significance, organization.
2. **Review of Relevant Literature**: navigation stack, detection, synthetic data, template matching, fusion, semantic and topological mapping; summary table; key findings; research gaps.
3. **Problem Statement and Objectives**: 3 research questions, problem statement, the 14 objectives in Table 3.1 (each with how the project addresses it, and a status), scope and limitations.
4. **Methodology**: architecture and design decisions; detection, sign perception, LiDAR-camera fusion (with equation), tracking and TTC, topological memory (with edge-cost equation), dashboard (Fig. 4.2); Nav2 configuration; robot and sensor table; simulated facility and dynamic agents; data acquisition (v2.5 dataset); implementation (Docker).
5. **Results and Discussion**: detector progression and the data-leakage finding; v2.5 accuracy; stress subsets; controlled tests A-H; live checks; sign, fusion, replanning and scenario tests; ten-mission benchmark with v2.4 comparison; ablation; comparative analysis; discussion; limitations table (from Soham's audit); summary.
6. **Work to be Done**: conclusion and the V2.6 targets.
- **Annexure I**: deployment defects. **Annexure II**: facility object inventory and semantic destinations.

Build: `pdflatex main.tex`, `bibtex main`, `pdflatex main.tex` twice. Or upload the zip to Overleaf. Template rules: edit only the chapter files, keep figures in `Figures/`, use `[H]` floats, and label and cite everything.

## Current story
- **Detector:** v2.5 YOLOv8n reaches 0.899 mAP@0.50 on the leak-free validation and test splits (v2.4 scores 0.634 on the same split). Its earlier reported 0.910 was inflated by 35 cross-split duplicate pairs. Inference is 4.06 ms per image, about 175 MB of GPU memory.
- **Controlled tests:** no false positives on empty hallways, walls or shadows. Recall: bed 90%, cart 73%, forklift 77%, person 100%, directional signs 58% (35% at near range).
- **Planning:** 0.05 ms median replan, 0 dead-end entries across 7 destinations.
- **Ten-mission Gazebo benchmark:** **0 of 10 completed** (v2.4: 3 of 10). 230.84 m travelled, 0 collisions, 327 replans (v2.4: 111), 95 TTC yields (v2.4: 30), effective speed 0.125 m/s (v2.4: 0.205).
- **Causes** (Soham's audit): TTC ignores the robot's own speed and fires on static objects; the stuck timer fires during yields; 30 blocked edges persist in SQLite; Nav2 cost-regulated speed and stop-and-go waypoints; a trapped start pose in the hospital ward; mission 10 has a 220 s limit against 180 s for the others.
- **Objective status (Table 3.1):** achieved 2, 3, 7, 11, 12, 13, 14; achieved with a qualifier 4, 9, 10; partly achieved 1, 5, 6, 8. The status labels are judgments. Change them only when new evidence supports it. Keep the 0/10 result honest.
- **Source:** Soham's repo `github.com/daradesoham-cyber/CV_Autonomous_Navigation`, commit `0ef2f8b` (tag `v2.5.0`). Where sources conflict, Soham's figures take precedence, and the facility inventory table Zubin gave is the final version.

## Ground rules for this project
- **Stay inside the template.** Keep the template's chapter and section headings and the guidelines' rules: edit only the chapter files, images in `Figures/`, `[H]` floats, a label and a descriptive caption on every figure, table and equation, BibTeX for all references, compile `pdflatex`, `bibtex`, `pdflatex`, `pdflatex`. Don't change the core of `main.tex`. Chapter 6 keeps the template's name "Work to be Done".
- **Soham's figures take precedence** over earlier sources. The facility inventory table Zubin gave is the final version. If Soham's own documents disagree, prefer his raw results files, then his spec, then his markdown reports, and flag the conflict to him.
- **Never fabricate or overstate.** Keep the 0/10 mission result. Change an objective's status in Table 3.1 only when new evidence supports it. Do not add a reference you have not verified.
- **Retired claims, do not bring them back:** the v1 figure of 96.2% and the v2.4 figure of 0.910 as evidence (both were in-distribution or leaky); "TTC yields fell from 300 to 95" (v2.4 had 30 and v2.5 has 95); "v2.4 completed 2/10 missions" (the spec says 3/10).
- **Do not mention Zubin's own machine** (host OS, GPU model). Detector metrics are from the RTX 3050 setup; the environment is described as an Ubuntu 26.04 container.
- **AI-use disclosure is not required**, and the report contains no such statement.
- **Furniture and racks in Annexure II** are listed with the class "obstacle"; the report says this is the inventory's assumption and was not tested. Keep that caveat unless Soham has a test.
- **Keep the evidence tags in Chapter 5** ("re-run and verified", "recorded in the repo", "reported only") so every claim shows how strong its evidence is.
- **Privacy:** crop screenshots so no browser tabs, notifications or personal information show.
- **Finish clean:** the PDF must build with no LaTeX errors and no "??" references.

## Where each number comes from
Files named below are in Soham's repo at commit `0ef2f8b`. "Read directly" means the raw file was opened; everything else was taken from a document that quotes it, and should be checked against the raw file.

| Report item | Source |
|---|---|
| Tables 5.1, 5.2 (v2.5 columns), 5.3 (v2.5 column): overall, per-class, stress subsets | `yolov8n_v25_metrics.json` (read directly) |
| Table 5.2 (v2.4 AP column), Table 5.3 (v2.4 column), leakage finding (83 pairs, 35 crossing), YOLOv8s numbers, dataset and training details (2,000 images, 15% negatives, 33 signs, 30 epochs) | `YOLO_V25_TRAINING_REPORT.md`; the v2.4 numbers originate in `v24_on_v25_benchmark.json` and `yolov8s_v25_metrics.json`, neither read directly |
| Table 5.4 controlled tests A-H | `controlled_perception_tests_v25.json` (read directly); the PASS/FAIL discrepancy is from `V2.5_PERCEPTION_FULL_SYSTEM_VALIDATION_REPORT.md` section 7 |
| Live ROS 2 checks (119 frames, 33/33 signs, 7.83 ms) | `YOLO_V25_TRAINING_REPORT.md` section 8.2 |
| Live Gazebo telemetry (14.8 ms, 33.8 Hz, 12% GPU, 173 MB) | `V2.5_PERCEPTION_FULL_SYSTEM_VALIDATION_REPORT.md` section 8 |
| Table 5.8 per-mission results | `V2.5_PERCEPTION_FULL_SYSTEM_VALIDATION_REPORT.md` section 10.1; totals cross-checked in `V2.5_CLAUDE_FINAL_REVIEW_REPORT.md` and in Soham's spec section 8 |
| Table 5.9 v2.4 versus v2.5 missions, latency and memory comparison, Table 3.1 speed and memory figures | Soham's spec section 8, which cites `v24_mission_validation_results.json` (not read directly) |
| Table 5.11 limitations and root causes, V2.6 targets in Chapter 6 | Soham's spec sections 9 and final summary |
| Tables 4.2, 4.3 (Nav2 settings, robot and sensors), thresholds, tracking, TTC and sign-gate parameters, edge-cost weights, database tables | Soham's spec sections 1, 4, 5 and 6 |
| Facility dimensions, corridor widths, Annexure II.3 destinations | Soham's spec section 3 |
| Table 4.4 and Annexure II.1 (facility inventory) | The final inventory table Zubin pasted (Soham's spec section 7 adds the patrol details) |
| Table 5.5 fusion accuracy, Table 5.6 replanning timing (38-node graph), Table 5.7 scenarios and scenario 1 (15/15 signs), Table 5.10 ablation, 29.18 m traversal claim, Annexure I defects | The original report by Zubin's team (`CV_Autonomous_Navigation_Report.tex`); these are older and not from the v2.5 documents |
| The 14 objectives | Pasted by Zubin from Soham |
| Objective statuses in Table 3.1 | Judgments by the assistant (Claude), from the evidence above |
| The 14 literature references | Each checked against a web-search result (publisher, arXiv, dblp or Semantic Scholar); summaries are from abstracts |

## Pending tasks
1. **Evidence gaps** (the dashboard screenshot is done): v2.5 confusion matrix and PR curves (Soham has them in `runs/train/yolov8n_v25/`); a pipeline figure (objective 3); mission trajectory plots (objective 1); a live-Gazebo fusion validation (objective 4).
2. **When Soham pushes V2.6:** check for commits after `0ef2f8b`, read `v24_mission_validation_results.json` directly, then update the mission tables (5.8, 5.9), the statuses in Table 3.1, the limitations, the summary and Chapter 6.
3. **Verify the numbers against the raw files** (`yolov8n_v25_metrics.json`, `controlled_perception_tests_v25.json`, `v24_mission_validation_results.json`). So far they come from Soham's markdown reports and spec, not from the JSON itself.
4. **Get Soham to resolve conflicts in his spec:** camera field of view versus focal length; 16 signs in the world versus 33 sign textures; the 38-node graph (older tests) versus the 48-node graph; the live sign test (33/33) versus the controlled test (58%); the person's speed (0.30 versus about 0.35 m/s).
5. **Housekeeping:** read the whole PDF page by page and fix any overfull lines or tables.


## Update after V2.6 (tag v2.6.0, commit 25bab3f, branch v2.6-dev)
- Report now includes: v2.5 confusion matrix and PR curve (Figs 5.1, 5.2), pipeline figure (Fig 4.2), V2.6 fixes (Section 5.1.15), V2.6 experiments (5.1.16), V2.6 benchmark marked "reported only" (5.1.17).
- Table 5.9 now compares the final v2.4 run (2/10, 300 yields, from v24_mission_validation_results.json at c732938) with v2.5; the Step F baseline (3/10, 160 s limit, older world) is shown for completeness. The earlier "retired claims" note is superseded: the raw files support 2/10 and 300 yields.
- v2.4 inference is 3.94 ms (raw benchmark), not 5.70 ms; the "faster" claim is removed.
- Eq. 4.1 now matches the fusion code (linear pixel-to-angle mapping, FOV 1.15 rad, fx about 494 px).
- The V2.6 10/10 result is NOT used as evidence: values are typed into compile_final_benchmark_results.py, speeds do not match distance/time, and the ward start stays trapped in Soham's own experiments. When Soham pushes the real v26_mission_validation_results.json, update Tables 3.1, 5.8/5.9, Section 5.1.17 and Chapter 6.
- Ask Soham to check nav2_params.yaml: in V2.6 the local_costmap block is nested under controller_server.
- Old v1 confusion matrix removed from Figures/.

## Update: real V2.6 benchmark (supplied by the team)
- Section 5.1.17 now holds the team's V2.6 run: 5/10 passed (M1, M4, M6, M7, M10), 0 collisions, 348.90 m in 1363.19 s (0.256 m/s), 180 s limit for every mission.
- The typed-in 10/10 is superseded and not used. Failed missions are reported as they happened; no values were invented.
- Still needed: Soham should commit the raw results file (with replans, TTC yields, min clearance) so the table can cite it.

## Update: V3.0 added (tag v3.0, commit a8ac484)
- New Section 5.1.18 "V3.0: Hospital Logistics Extension" with Tables 5.14-5.16 and Figs 5.3-5.4 (hospital lobby view; recorded mission paths plotted from V3/docs/evidence/new_hospital/missions/*).
- All V3 numbers checked against raw files: phase2_eval/evaluation.json (detector), phase3_fusion/fusion_eval.json (fusion), new_hospital/missions/*/summary.json and mission_*.json (missions; distances recomputed from logged paths, within 0.5 m).
- V3 sentences appended to Table 3.1 (objectives 1, 2, 4), the Discussion, the summary and Chapter 6. Existing V2.6 text unchanged.
- Caveats stated in the report: V3 missions repeat one route; the detector has no labelled test in the AWS hospital (confidence only); v2.5 scores 0.106 on Gazebo renders.
- Start poses and graph size updated to the V2.6 recovery commit 5312068 (53 nodes; hospital/Room B (5.0, -9.0); loading (12.8, 2.0)).
